<?php

use App\Http\Controllers\CetakController;
use App\Http\Controllers\DataBarang;
use Illuminate\Support\Facades\Route;
use TCG\Voyager\Facades\Voyager; 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('overview');
});

//Get Barang by ID Ruang
Route::get('/admin/ruangs/{id}/detail', [DataBarang::class, 'dataBarang']);

//Cetak PDF
Route::get('/cetak/pdf/view/ruangs', [CetakController::class, 'showRuang']);
Route::get('/cetak/pdf/ruangs', [CetakController::class, 'cetakPDFRuang']);
Route::get('/cetak/pdf/view/barangs', [CetakController::class, 'showBarang']);
Route::get('/cetak/pdf/barangs', [CetakController::class, 'cetakPDFBarang']);

//Cetak Excel
Route::get('/cetak/excel/view/ruangs', [CetakController::class, 'showRuang']);
Route::get('/cetak/excel/ruangs', [CetakController::class, 'cetakExcelRuang']);
Route::get('/cetak/excel/view/barangs', [CetakController::class, 'showBarang']);
Route::get('/cetak/excel/barangs', [CetakController::class, 'cetakExcelBarang']);

Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});
